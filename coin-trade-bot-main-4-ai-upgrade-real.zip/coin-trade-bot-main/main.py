import os
import time
import threading
import requests
try:
    from dotenv import load_dotenv
except Exception:
    def load_dotenv(*args, **kwargs):
        return False

try:
    from flask import Flask, jsonify
except Exception:
    class Flask:
        def __init__(self, name):
            self.name = name
        def get(self, _path):
            def deco(fn):
                return fn
            return deco
        def run(self, host="0.0.0.0", port=8080):
            print(f"[WARN] Flask not installed. Web server disabled ({host}:{port})", flush=True)
    def jsonify(obj):
        return obj

load_dotenv()

import trader as trader_module
import ai_score_runtime_patch  # noqa: F401
import trader_ai_upgrade_patch  # noqa: F401
from trader import Trader


def _attach_compat_hotfix() -> None:
    """Attach compatibility methods expected by older runtime patches."""
    try:
        has_module_fn = hasattr(trader_module, "compute_signal_and_exits")
        has_class_fn = hasattr(Trader, "compute_signal_and_exits")
        if has_module_fn and not has_class_fn:
            def _compat_compute_signal_and_exits(self, symbol, side, price, mp, avoid_low_rsi=False):
                return trader_module.compute_signal_and_exits(
                    symbol, side, price, mp, avoid_low_rsi=avoid_low_rsi
                )
            Trader.compute_signal_and_exits = _compat_compute_signal_and_exits
            print("[COMPAT_HOTFIX] Trader.compute_signal_and_exits attached", flush=True)
    except Exception as e:
        print(f"[COMPAT_HOTFIX] attach failed: {e}", flush=True)


_attach_compat_hotfix()

app = Flask(__name__)

BOT_TOKEN = (os.getenv("BOT_TOKEN", "") or "").strip()
CHAT_ID_ENV = (os.getenv("CHAT_ID", "") or "").strip()
TELEGRAM_API = f"https://api.telegram.org/bot{BOT_TOKEN}" if BOT_TOKEN else ""
PROXY = os.getenv("HTTPS_PROXY") or os.getenv("HTTP_PROXY") or ""
PROXIES = {"http": PROXY, "https": PROXY} if PROXY else None
PORT = int(os.getenv("PORT", "8080"))
POLL_TIMEOUT = int(os.getenv("TG_POLL_TIMEOUT", "25"))
POLL_SLEEP = float(os.getenv("TG_POLL_SLEEP", "0.5"))
TRADING_TICK_SEC = float(os.getenv("TRADING_TICK_SEC", "5"))

state = {
    "running": True,
    "last_heartbeat": None,
    "last_event": None,
    "last_error": None,
    "last_telegram": None,
    "chat_id": CHAT_ID_ENV or None,
}

if CHAT_ID_ENV:
    trader_module.CHAT_ID = CHAT_ID_ENV

trader = Trader(state)
_runtime_chat_id = CHAT_ID_ENV


@app.get("/")
def home():
    return "Bot Running"


@app.get("/health")
def health():
    try:
        ps = trader.public_state() if hasattr(trader, "public_state") else {}
    except Exception as e:
        ps = {"public_state_error": str(e)}
    return jsonify({**state, **ps})


def tg_send(msg: str, reply_markup: dict | None = None):
    global _runtime_chat_id
    print(msg, flush=True)
    if not TELEGRAM_API:
        return
    chat_id = _runtime_chat_id or CHAT_ID_ENV
    if not chat_id:
        print("[TG] chat_id unknown. Waiting for first incoming message.", flush=True)
        return
    payload = {"chat_id": chat_id, "text": msg}
    if reply_markup is not None:
        payload["reply_markup"] = reply_markup
    try:
        requests.post(
            f"{TELEGRAM_API}/sendMessage",
            json=payload,
            timeout=15,
            proxies=PROXIES,
        )
    except Exception as e:
        print(f"[TG] send error: {e!r}", flush=True)


def telegram_loop():
    global _runtime_chat_id
    offset = None
    print(
        f"[TG] loop start TELEGRAM_API={bool(TELEGRAM_API)} CHAT_ID_ENV={bool(CHAT_ID_ENV)}",
        flush=True,
    )
    while True:
        try:
            if not TELEGRAM_API:
                print("[TG] TELEGRAM_API missing", flush=True)
                time.sleep(2)
                continue

            r = requests.get(
                f"{TELEGRAM_API}/getUpdates",
                params={"timeout": POLL_TIMEOUT, "offset": offset},
                timeout=POLL_TIMEOUT + 10,
                proxies=PROXIES,
            )
            data = r.json()

            for item in data.get("result", []):
                offset = item["update_id"] + 1
                msg = item.get("message", {}) or {}
                text = (msg.get("text", "") or "").strip()

                try:
                    chat_id = str((msg.get("chat") or {}).get("id") or "")
                    if chat_id:
                        _runtime_chat_id = chat_id
                        state["chat_id"] = chat_id
                        trader_module.CHAT_ID = chat_id
                except Exception:
                    pass

                if not text:
                    continue

                state["last_telegram"] = time.time()
                print(f"[TG] CMD: {text}", flush=True)
                try:
                    if hasattr(trader, "handle_command"):
                        trader.handle_command(text)
                    elif text == "/status":
                        tg_send(str(trader.public_state()))
                except Exception as e:
                    print(f"[TG] trader.handle_command crash: {e!r}", flush=True)
                    state["last_error"] = f"tg_cmd: {e}"
        except Exception as e:
            print(f"[TG] polling error: {e!r}", flush=True)
            state["last_error"] = f"polling: {e}"
            time.sleep(3)

        time.sleep(POLL_SLEEP)


def trading_loop():
    while True:
        try:
            state["running"] = bool(getattr(trader, "trading_enabled", True))
            if state["running"]:
                trader.tick()
            state["last_heartbeat"] = time.time()
            time.sleep(TRADING_TICK_SEC)
        except Exception as e:
            print(f"[TRADING] loop crash: {e!r}", flush=True)
            state["last_error"] = f"trading_loop: {e}"
            time.sleep(3)


if __name__ == "__main__":
    print("[BOOT] Bot starting...", flush=True)
    threading.Thread(target=telegram_loop, daemon=True).start()
    threading.Thread(target=trading_loop, daemon=True).start()
    app.run(host="0.0.0.0", port=PORT)
